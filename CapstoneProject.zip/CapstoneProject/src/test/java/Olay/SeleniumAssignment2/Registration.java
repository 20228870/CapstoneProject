package Olay.SeleniumAssignment2;

public class Registration {
	

}
